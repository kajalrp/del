﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practicedatabase
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }


        private void ShowModuleDetails()
        {
            //retive result from database using datacontext.
            List<Practice> traineeDetailsList = dbContext.Practices.ToList();
            //linq query to retrive records from database having batch name is ".Net Batch".
            var res = traineeDetailsList.Select(s => new { s.PatId, s.PatFirstName, s.PatLastName, s.PatGender,s.Payment,s.PatPhoneNo });

            //assign result to datagrid.
            dgPractice.ItemsSource = res;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowModuleDetails();
        }
    }
}

