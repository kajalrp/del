﻿create table [Mayuri_Mhatre].[Layered_Product]
(
    [Id]       INT IDENTITY (1, 1) NOT NULL,
    [ProdName] VARCHAR (20) NULL,
    [Price]    DECIMAL (18) NULL,
    [ExpDate]  DATE         NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

insert into [Mayuri_Mhatre].[Layered_Product] ([ProdName],[Price],[ExpDate]) values ('Keyboard',100.0,'12/31/2009');

select * from Mayuri_Mhatre.Layered_Product

insert into Mayuri_Mhatre.Layered_Product values ('Mouse',50.0,'4/12/2008');

 insert into Mayuri_Mhatre.Layered_Product values ('Printer',90.0,'4/12/2008');

 create procedure Mayuri_Mhatre.USP_InsertProduct_Layered 
		@pName varchar (20),
		@price decimal(18),
		@exDate date
 as 
 insert into Mayuri_Mhatre.Layered_Product values(@pName, @price, @exDate);

 create procedure Mayuri_Mhatre.USP_UpdateProduct_Layered 
		@id int ,
		@pName varchar (20),
		@price decimal(18),
		@exDate date
 as 
 update Mayuri_Mhatre.Layered_Product set ProdName=@pName, Price=@price, ExpDate=@exDate where Id = @id;

create procedure Mayuri_Mhatre.USP_DeleteProduct_Layered1 
		@id int 	
 as 
 delete from  Mayuri_Mhatre.Layered_Product where Id=@id;