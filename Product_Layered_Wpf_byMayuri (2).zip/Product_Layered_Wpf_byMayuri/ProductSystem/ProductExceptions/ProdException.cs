﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ProductExceptions
{
    [Serializable]
    public class ProdException : Exception
    {
        public ProdException()
        {
        }

        public ProdException(string message) : base(message)
        {
        }

        public ProdException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ProdException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}


