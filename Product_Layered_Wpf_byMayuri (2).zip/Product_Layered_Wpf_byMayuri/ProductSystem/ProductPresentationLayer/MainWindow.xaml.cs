﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductSystem_Entities;
using ProductExceptions;
using ProductBusinessLayer;



namespace ProductPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

      //  ProductBL objBL = new ProductBL();
        Product p = null;

        public bool IsInputValid()
        {
            bool isValid = false;
            StringBuilder sb = new StringBuilder();
            
            //names of the wpf window text boxes n all.
            if (cmbProdName.Text == null | cmbProdName.Text == string.Empty | cmbProdName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (dpExDate.Text == null | dpExDate.Text == string.Empty | dpExDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }
            if (!isValid)
            {
                throw new ProdException(sb.ToString());
            }
            return isValid;
        }


        public void PopulateUI()
        {
            List<Product> pro = ProductBL.SelectAllBL();
            dgProducts.ItemsSource = pro;
            cmbProdName.ItemsSource = pro;
            txtTotalCount.Text = pro.Count().ToString();
            cmbProdName.DisplayMemberPath = "ProdName";
        }

      
        private void Button_UpdateClick(object sender, RoutedEventArgs e)
        {
            try
            {
              
                //p = (Product)cmbProdName.SelectedItem;
                p.ProdName = cmbProdName.Text;
                p.Exdate = Convert.ToDateTime(dpExDate.Text);
                p.Price = Convert.ToDecimal(txtPrice.Text);
                ProductBL.UpdateBL(p);
                MessageBox.Show("Updated");
                PopulateUI();
            }
            /*catch (ProdException ex1)
            {
                MessageBox.Show(ex1.Message);
            }*/
            catch (ProdException ex1)
            {

                throw ex1;
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }

        }

        private void Button_InsertClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {

                    Product p = new Product
                    {
                        ProdName = cmbProdName.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        Exdate = Convert.ToDateTime(dpExDate.Text)
                    };
                    ProductBL.InsertBL(p);
                    MessageBox.Show("Inserted");
                    PopulateUI();
                }
                
            }
            catch (ProdException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }


     

        private void Button_DeleteClick(object sender, RoutedEventArgs e)
        {
            try
            {
                 p = (Product)cmbProdName.SelectedItem;

                ProductBL.DeleteProdBL(p);
                MessageBox.Show("Deleted");
                PopulateUI();
            }
            catch (ProdException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {

                throw;
            }

        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void CmbProdName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // p = (Product)cmbProdName.SelectedItem;
           // MessageBox.Show(p.Id.ToString(),p.ProdName.ToString());
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            //first  click on edit button and then update
            p = (Product)cmbProdName.SelectedItem;

        }

    }
}
