﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductSystem_Entities
{
    public class Product
    {
        public int Id { get; set; }
        public string ProdName { get; set; }
        public DateTime Exdate { get; set; }
        public Decimal Price { get; set; }
    }
}
