﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductSystem_Entities;
using ProductExceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace ProductdataAccessLayer
{
    public class ProductDAL
    {
     
        //u need to first create schema and create table then use following things.
        SqlConnection cn = null;//to instantiate in respective operations.
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ProductDAL()
        {//to instatntiate 
            //goto connection->right click->properties->connection String ->copy it.
            //System.Configuration is added otherwise ConfigurationManager will give error.
            //ConnectionStrings["cn1"] this is name
            //.ConnectionString is function
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool InsertDAL(Product product)
        {
            bool prodAdded = false;
            try
            {
                //cmd = new SqlCommand("insert into Mayuri_Mhatre.Layered_Product values(@pName, @price, @exDate)", cn);
                //add parameters before opening
                cmd = new SqlCommand("Mayuri_Mhatre.USP_InsertProd_Layered", cn );
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@exDate", product.Exdate);

                cn.Open();
                int row=cmd.ExecuteNonQuery();//as insert is non query
                if (row > 0)
                    prodAdded = true;
            }
            
            catch (ProdException ex2)
            {
                //click to get bulb and autogenerate udException class
                throw ex2;
            }
            catch (Exception ex1)
            {

                throw ex1;
            }

            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return prodAdded;
        }

        public bool UpdateDAL(Product product)
        {
            bool prodUpdated = false;
            try
            {
               // cmd = new SqlCommand("update Mayuri_Mhatre.Layered_Product set ProdName=@pName, Price=@price, ExpDate=@exDate where Id = @id", cn);
                //add parameters before opening
                 cmd = new SqlCommand("Mayuri_Mhatre.USP_UpdateProd_Layered", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@exDate", product.Exdate);

                cn.Open();
                int row=cmd.ExecuteNonQuery();//as insert is non query
                if (row > 0)
                    prodUpdated = true;
            }
            catch (ProdException ex2)
            {
                //click to get bulb and autogenerate udException class
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;

            }

            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return prodUpdated;
        }

        public List<Product> SelectAllDAL()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand(" select * from Mayuri_Mhatre.Layered_Product", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.Exdate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch (Exception ex1)
            {

                throw ex1;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }

            return products;
        }
        /*
        public bool DeleteDAL()
        {
            bool prodDeleted = false;
            try
            {
               cmd = new SqlCommand(" delete from  Mayuri_Mhatre.Layered_Product where Id=@id", cn);
                //cmd = new SqlCommand("Mayuri_Mhatre.USP_DeleteProduct_Layered", cn);
                // cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id",id);

                cn.Open();
                int row=cmd.ExecuteNonQuery();
                if (row > 0)
                    prodDeleted = true;
            }
            catch (Exception ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return prodDeleted;
        }
        */
       
         public bool DeleteDAL(Product product)
        {
            bool prodDeleted = false;
            try
            {
               // cmd = new SqlCommand(" delete from  Mayuri_Mhatre.Layered_Product where Id=@id", cn);

                cmd = new SqlCommand("Mayuri_Mhatre.USP_DeleteProd_Layered", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
               

                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    prodDeleted = true;
            }
            catch (ProdException ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return prodDeleted;
        }


    }
}


