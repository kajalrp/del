﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductSystem_Entities;
using ProductExceptions;
using ProductdataAccessLayer;

namespace ProductBusinessLayer
{
    public class ProductBL
    {
        private static bool ValidateProduct(Product prod)
        {
            StringBuilder sb = new StringBuilder();
            bool validProd = true;

            if (prod.Price< 0)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid Price");
            }
            if (prod.ProdName == string.Empty)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Product Name Required");
            }
            if (prod.Exdate.ToString().Length < 0)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid Expiry Date");
            }
            if (validProd == false)
            {
                throw new ProdException(sb.ToString());
            }
            return validProd;
        }

        public static List<Product> GetAllProdBL()
        {
            List<Product> prodList = null;
            try
            {
                ProductDAL objProDAL = new ProductDAL();
                prodList = objProDAL.SelectAllDAL();

            }
            catch (ProdException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {

                throw ex2;
            }
            return prodList;
        }

        public static bool InsertBL(Product prod)
        {
            bool prodInserted = false;
            try
            {
                if (ValidateProduct(prod))
                {
                    ProductDAL objProdDAL = new ProductDAL();
                    prodInserted = objProdDAL.InsertDAL(prod);//true value from DAL is received and stored here.
                }
                
            }
            catch (ProdException ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return prodInserted;
        }

        public static bool UpdateBL(Product prod)
        {
            bool prodUpdated = false;

            try
            {
                if (ValidateProduct(prod))
                {
                    ProductDAL objProdDAL = new ProductDAL();
                    prodUpdated = objProdDAL.UpdateDAL(prod);
                }
            }
            catch (ProdException ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodUpdated;
        }
      

        public static bool DeleteProdBL(Product product)
        {
            bool prodDeleted = false;

            try
            {

                ProductDAL prodDAL = new ProductDAL();
                prodDeleted = prodDAL.DeleteDAL(product);
                prodDeleted = prodDAL.DeleteDAL(product);



            }
            catch (ProdException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodDeleted;
        }




        public static List<Product> SelectAllBL()
        {
            List<Product> prodList = null;
            try
            {
                ProductDAL prodDAL = new ProductDAL();
                prodList = prodDAL.SelectAllDAL();
            }
            catch (ProdException ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodList;

        }

    }
}
